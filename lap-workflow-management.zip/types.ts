export enum UserRole {
  ADMIN = 'ADMIN',
  DESIGNER = 'DESIGNER',
  COMMERCIAL = 'COMMERCIAL',
  IMPRIMEUR = 'IMPRIMEUR',
}

export enum OrderStatus {
  NEW_ORDER = 'Nouvelle Commande',
  DESIGN_ASSIGNED = 'Design Assigné',
  DESIGN_IN_PROGRESS = 'Design en Cours',
  DESIGN_PENDING_APPROVAL = 'Design en Attente d\'Approbation',
  DESIGN_APPROVED = 'Design Approuvé',
  PRODUCTION_ASSIGNED = 'Production Assignée',
  PRODUCTION_IN_PROGRESS = 'Production en Cours',
  PRODUCTION_COMPLETE = 'Production Terminée',
  FINAL_PENDING_APPROVAL = 'Approbation Finale en Attente',
  COMPLETED = 'Terminée',
  CANCELED = 'Annulée'
}

export enum TaskStatus {
    PENDING = 'En attente',
    ACCEPTED = 'Acceptée',
    IN_PROGRESS = 'En cours',
    COMPLETED = 'Terminée',
    REJECTED = 'Rejetée'
}

export interface User {
  user_id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  roles: UserRole[];
  is_active: boolean;
}

export interface Customer {
  customer_id: number;
  company_name: string;
  contact_name: string;
  email: string;
}

export interface Product {
  product_id: number;
  product_name: string;
  unit_price: number;
}

export interface OrderItem {
  order_item_id: number;
  product_id: number;
  quantity: number;
  unit_price: number;
  total_price: number;
}

export interface Task {
    task_id: number;
    order_id: number;
    assigned_to: number;
    assigned_by: number;
    status: TaskStatus;
    step_name: string; // e.g., 'Design', 'Printing'
}

export interface Order {
  order_id: number;
  order_number: string;
  customer_id: number;
  status: OrderStatus;
  order_date: string;
  delivery_date: string;
  total_amount: number;
  created_by: number;
  items: OrderItem[];
  tasks: Task[];
}