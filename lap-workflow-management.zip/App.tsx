import React from 'react';
import { useAppContext } from './contexts/AppContext';
import LoginScreen from './components/views/LoginScreen';
import Dashboard from './components/views/Dashboard';
import Header from './components/common/Header';
import Sidebar from './components/common/Sidebar';
import OtpScreen from './components/views/OtpScreen';

const App: React.FC = () => {
  const { currentUser, isAwaitingOtp } = useAppContext();

  return (
    <div className="min-h-screen bg-background font-sans text-text-primary">
      {!currentUser ? (
        isAwaitingOtp ? <OtpScreen /> : <LoginScreen />
      ) : (
        <div className="flex h-screen">
          <Sidebar />
          <div className="flex-1 flex flex-col overflow-hidden">
            <Header />
            <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-4 sm:p-6 lg:p-8">
              <Dashboard />
            </main>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;