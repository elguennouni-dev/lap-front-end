import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';
import { User, UserRole } from '../types';
import { api } from '../services/api';

interface AppContextType {
  currentUser: User | null;
  isAwaitingOtp: boolean;
  login: (email: string, password: string) => Promise<{success: boolean; message: string}>;
  verifyOtp: (otp: string) => Promise<{success: boolean; message: string}>;
  logout: () => void;
  users: User[];
  refreshUsers: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAwaitingOtp, setIsAwaitingOtp] = useState<boolean>(false);
  const [userForOtp, setUserForOtp] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);

  const refreshUsers = useCallback(async () => {
    const fetchedUsers = await api.getUsers();
    setUsers(fetchedUsers);
  }, []);

  useEffect(() => {
    refreshUsers();
  }, [refreshUsers]);


  const login = async (email: string, password: string) => {
    // In a real app, password would be checked. Here we just find by email.
    const user = await api.getUserByEmail(email);
    if (!user) {
        return { success: false, message: 'Utilisateur non trouvé ou mot de passe incorrect.' };
    }

    if (user.roles.includes(UserRole.ADMIN)) {
        console.log("Admin login attempt. Simulating OTP dispatch to email.");
        setUserForOtp(user);
        setIsAwaitingOtp(true);
        return { success: true, message: 'OTP envoyé.' };
    } else {
        setCurrentUser(user);
        return { success: true, message: 'Connexion réussie.' };
    }
  };

  const verifyOtp = async (otp: string) => {
    // Dummy OTP check
    if (otp === '123456' && userForOtp) {
        setCurrentUser(userForOtp);
        setUserForOtp(null);
        setIsAwaitingOtp(false);
        return { success: true, message: 'Vérification réussie.' };
    } else {
        return { success: false, message: 'OTP invalide.' };
    }
  };


  const logout = () => {
    setCurrentUser(null);
    setIsAwaitingOtp(false);
    setUserForOtp(null);
  };

  return (
    <AppContext.Provider value={{ currentUser, isAwaitingOtp, login, verifyOtp, logout, users, refreshUsers }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};