import React, { useState, useRef, useEffect } from 'react';
import { useAppContext } from '../../contexts/AppContext';
import { UserRole } from '../../types';
import { Icon } from './Icon';
import NotificationPanel from './NotificationPanel';


const getRoleClass = (role: UserRole) => {
    switch(role) {
        case UserRole.ADMIN: return 'bg-red-500 text-white';
        case UserRole.COMMERCIAL: return 'bg-blue-500 text-white';
        case UserRole.DESIGNER: return 'bg-purple-500 text-white';
        case UserRole.IMPRIMEUR: return 'bg-green-500 text-white';
        default: return 'bg-gray-500 text-white';
    }
}

const Header: React.FC = () => {
    const { currentUser, logout } = useAppContext();
    const [showNotifications, setShowNotifications] = useState(false);
    const notificationRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
                setShowNotifications(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    if (!currentUser) return null;

    return (
        <header className="bg-surface shadow-md p-4 flex justify-end items-center border-b border-border flex-shrink-0">
            <div className="flex items-center space-x-4">
                <div className="relative" ref={notificationRef}>
                    <button 
                        onClick={() => setShowNotifications(!showNotifications)}
                        className="relative text-text-secondary hover:text-text-primary transition-colors"
                        aria-label="Notifications"
                    >
                        <Icon name="notification" className="h-6 w-6"/>
                        <span className="absolute -top-1 -right-1 flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                        </span>
                    </button>
                    {showNotifications && <NotificationPanel />}
                </div>
                <div className="w-px h-6 bg-border"></div>
                <div className="text-right">
                    <p className="font-semibold text-sm">{currentUser.first_name} {currentUser.last_name}</p>
                    <div className="flex items-center justify-end space-x-1">
                        {currentUser.roles.map(role => (
                            <span key={role} className={`text-xs font-bold px-2 py-0.5 rounded-full ${getRoleClass(role)}`}>
                                {role}
                            </span>
                        ))}
                    </div>
                </div>
                <button 
                    onClick={logout}
                    className="flex items-center bg-gray-700 hover:bg-red-700 text-white font-bold py-2 px-3 rounded-lg transition-colors duration-200"
                    aria-label="Logout"
                >
                    <Icon name="logout" className="h-5 w-5"/>
                </button>
            </div>
        </header>
    );
};

export default Header;