import React from 'react';
import { Icon } from './Icon';

const NavLink: React.FC<{ icon: string; label: string; active?: boolean }> = ({ icon, label, active }) => (
    <a href="#" className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors duration-200 ${active ? 'bg-primary text-white' : 'text-text-secondary hover:bg-surface hover:text-text-primary'}`}>
        <Icon name={icon} className="h-6 w-6" />
        <span className="font-semibold">{label}</span>
    </a>
);

const Sidebar: React.FC = () => {
    return (
        <aside className="w-64 bg-surface border-r border-border flex-shrink-0 flex flex-col">
            <div className="h-16 flex items-center justify-center border-b border-border flex-shrink-0">
                <div className="flex items-center space-x-2">
                    <Icon name="logo" className="h-8 w-8 text-primary"/>
                    <h1 className="text-2xl font-bold text-text-primary">LAP</h1>
                </div>
            </div>
            <nav className="flex-1 p-4 space-y-2">
                <NavLink icon="dashboard" label="Tableau de bord" active />
                <NavLink icon="order" label="Commandes" />
                <NavLink icon="user" label="Clients" />
                <NavLink icon="user" label="Utilisateurs" />
            </nav>
            <div className="p-4 border-t border-border">
                {/* Footer or extra links can go here */}
            </div>
        </aside>
    );
};

export default Sidebar;
