import React from 'react';
import { Icon } from './Icon';

const mockNotifications = [
    { id: 1, icon: 'order', text: "La commande CMD-005 est terminée.", time: "il y a 5 minutes" },
    { id: 2, icon: 'task', text: "Nouvelle tâche 'Design' assignée pour CMD-002.", time: "il y a 1 heure" },
    { id: 3, icon: 'user', text: "Le client Wayne Enterprises a été ajouté.", time: "il y a 3 heures" },
    { id: 4, icon: 'order', text: "Le design pour CMD-004 a été approuvé.", time: "hier" },
];

const NotificationPanel: React.FC = () => {
    return (
        <div className="absolute right-0 mt-2 w-80 bg-surface rounded-lg shadow-lg border border-border z-20">
            <div className="p-4 border-b border-border">
                <h3 className="font-semibold text-text-primary">Notifications</h3>
            </div>
            <div className="divide-y divide-border max-h-96 overflow-y-auto">
                {mockNotifications.map(notif => (
                    <div key={notif.id} className="p-4 flex items-start space-x-3 hover:bg-gray-800">
                        <div className="bg-primary/20 p-2 rounded-full">
                            <Icon name={notif.icon} className="h-5 w-5 text-primary"/>
                        </div>
                        <div>
                            <p className="text-sm text-text-primary">{notif.text}</p>
                            <p className="text-xs text-text-secondary mt-1">{notif.time}</p>
                        </div>
                    </div>
                ))}
            </div>
             <div className="p-2 border-t border-border text-center">
                <a href="#" className="text-sm text-primary hover:underline font-medium">Voir tout</a>
            </div>
        </div>
    );
};

export default NotificationPanel;
