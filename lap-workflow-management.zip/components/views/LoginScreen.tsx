import React, { useState } from 'react';
import { useAppContext } from '../../contexts/AppContext';
import { Icon } from '../common/Icon';

const LoginScreen: React.FC = () => {
    const { login } = useAppContext();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        const result = await login(email, password);
        if (!result.success) {
            setError(result.message);
        }
        setLoading(false);
    };

    const handleQuickLogin = (email: string) => {
        setEmail(email);
        setPassword('password'); // Dummy password for mock login
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-background p-4">
            <div className="w-full max-w-md p-8 space-y-6 bg-surface rounded-xl shadow-lg border border-border">
                <div className="text-center">
                    <Icon name="logo" className="mx-auto h-12 w-12 text-primary"/>
                    <h2 className="mt-6 text-3xl font-extrabold text-text-primary">
                        Connexion à LAP
                    </h2>
                    <p className="mt-2 text-sm text-text-secondary">
                        Veuillez entrer vos identifiants pour continuer.
                    </p>
                </div>
                <form className="space-y-6" onSubmit={handleLogin}>
                    <div>
                        <label htmlFor="email" className="text-sm font-bold text-gray-400 tracking-wide">Email</label>
                        <div className="relative">
                           <div className="absolute top-1/2 -translate-y-1/2 left-3">
                             <Icon name="mail" className="w-5 h-5 text-gray-400"/>
                           </div>
                           <input
                            id="email"
                            name="email"
                            type="email"
                            autoComplete="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full text-base py-2 pl-10 pr-4 rounded-lg border border-border bg-gray-800 focus:outline-none focus:border-primary"
                            placeholder="mail@example.com"
                           />
                        </div>
                    </div>
                     <div>
                        <label htmlFor="password-" className="text-sm font-bold text-gray-400 tracking-wide">Mot de passe</label>
                        <div className="relative">
                            <div className="absolute top-1/2 -translate-y-1/2 left-3">
                             <Icon name="key" className="w-5 h-5 text-gray-400"/>
                           </div>
                           <input
                            id="password"
                            name="password"
                            type="password"
                            autoComplete="current-password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full text-base py-2 pl-10 pr-4 rounded-lg border border-border bg-gray-800 focus:outline-none focus:border-primary"
                            placeholder="Entrez votre mot de passe"
                           />
                        </div>
                    </div>
                    {error && <p className="text-sm text-red-500 text-center">{error}</p>}
                    <div>
                        <button type="submit" disabled={loading} className="w-full flex justify-center bg-primary text-gray-100 p-3 rounded-full tracking-wide font-semibold cursor-pointer transition ease-in duration-300 hover:bg-red-700 disabled:opacity-50">
                           {loading ? 'Connexion...' : 'Se connecter'}
                        </button>
                    </div>
                </form>
                <div className="text-center text-xs text-text-secondary mt-4">
                    <p>Pour la démo, utilisez :</p>
                    <div className="flex justify-center space-x-2 mt-2">
                        <button onClick={() => handleQuickLogin('admin@example.com')} className="text-primary hover:underline">Admin</button>
                        <span>•</span>
                        <button onClick={() => handleQuickLogin('commercial@example.com')} className="text-primary hover:underline">Commercial</button>
                        <span>•</span>
                        <button onClick={() => handleQuickLogin('designer1@example.com')} className="text-primary hover:underline">Designer</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginScreen;