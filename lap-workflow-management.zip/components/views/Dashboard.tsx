import React from 'react';
import OrderKanbanView from './OrderKanbanView';
import { useAppContext } from '../../contexts/AppContext';
import { Icon } from '../common/Icon';

const StatCard: React.FC<{title: string; value: string; icon: string}> = ({ title, value, icon }) => (
    <div className="bg-surface p-6 rounded-lg border border-border flex items-center space-x-4">
        <div className="bg-primary/20 p-3 rounded-full">
            <Icon name={icon} className="h-6 w-6 text-primary" />
        </div>
        <div>
            <p className="text-sm text-text-secondary font-medium">{title}</p>
            <p className="text-2xl font-bold text-text-primary">{value}</p>
        </div>
    </div>
);


const Dashboard: React.FC = () => {
  const { currentUser } = useAppContext();

  return (
    <div className="space-y-6">
      <div className="p-6 bg-surface rounded-lg border border-border">
        <h1 className="text-2xl font-bold text-text-primary">Bienvenue, {currentUser?.first_name}!</h1>
        <p className="text-text-secondary mt-1">Voici l'état actuel de toutes les commandes. Vous pouvez les gérer en fonction de votre rôle.</p>
      </div>
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard title="Nouvelles Commandes" value="3" icon="order" />
            <StatCard title="Tâches Assignées" value="8" icon="task" />
            <StatCard title="Clients Actifs" value="12" icon="user" />
            <StatCard title="Commandes Terminées (Mois)" value="42" icon="order" />
        </div>
      <OrderKanbanView />
    </div>
  );
};

export default Dashboard;