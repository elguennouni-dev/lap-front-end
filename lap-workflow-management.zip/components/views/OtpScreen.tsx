import React, { useState } from 'react';
import { useAppContext } from '../../contexts/AppContext';
import { Icon } from '../common/Icon';

const OtpScreen: React.FC = () => {
    const { verifyOtp } = useAppContext();
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleVerify = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        const result = await verifyOtp(otp);
        if (!result.success) {
            setError(result.message);
        }
        setLoading(false);
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-background p-4">
            <div className="w-full max-w-md p-8 space-y-6 bg-surface rounded-xl shadow-lg border border-border">
                <div className="text-center">
                    <Icon name="logo" className="mx-auto h-12 w-12 text-primary"/>
                    <h2 className="mt-6 text-3xl font-extrabold text-text-primary">
                        Vérification OTP
                    </h2>
                    <p className="mt-2 text-sm text-text-secondary">
                        Un code a été envoyé à votre email. Entrez-le ci-dessous. (Hint: c'est 123456)
                    </p>
                </div>
                <form className="space-y-6" onSubmit={handleVerify}>
                    <div>
                        <label htmlFor="otp" className="text-sm font-bold text-gray-400 tracking-wide">Code OTP</label>
                         <input
                          id="otp"
                          name="otp"
                          type="text"
                          maxLength={6}
                          value={otp}
                          onChange={(e) => setOtp(e.target.value)}
                          className="w-full text-center text-2xl tracking-[1em] py-2 rounded-lg border border-border bg-gray-800 focus:outline-none focus:border-primary"
                          required
                         />
                    </div>
                    {error && <p className="text-sm text-red-500 text-center">{error}</p>}
                    <div>
                        <button type="submit" disabled={loading || otp.length < 6} className="w-full flex justify-center bg-primary text-gray-100 p-3 rounded-full tracking-wide font-semibold cursor-pointer transition ease-in duration-300 hover:bg-red-700 disabled:opacity-50">
                           {loading ? 'Vérification...' : 'Vérifier'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default OtpScreen;