import React, { useState, useEffect, useMemo } from 'react';
import { Order, OrderStatus, Customer } from '../../types';
import { api } from '../../services/api';
import OrderDetailModal from './OrderDetailModal';

const statusOrder: OrderStatus[] = [
    OrderStatus.NEW_ORDER,
    OrderStatus.DESIGN_ASSIGNED,
    OrderStatus.DESIGN_IN_PROGRESS,
    OrderStatus.DESIGN_PENDING_APPROVAL,
    OrderStatus.DESIGN_APPROVED,
    OrderStatus.PRODUCTION_ASSIGNED,
    OrderStatus.PRODUCTION_IN_PROGRESS,
    OrderStatus.PRODUCTION_COMPLETE,
    OrderStatus.FINAL_PENDING_APPROVAL,
    OrderStatus.COMPLETED,
];

const getStatusColorInfo = (status: OrderStatus): { border: string, text: string } => {
    if (status.includes('Attente') || status.includes('Assigné')) return { border: 'border-yellow-500', text: 'text-yellow-500' };
    if (status.includes('Cours')) return { border: 'border-blue-500', text: 'text-blue-500' };
    if (status.includes('Approuvé') || status.includes('Terminée')) return { border: 'border-green-500', text: 'text-green-500' };
    if (status === OrderStatus.COMPLETED) return { border: 'border-emerald-500', text: 'text-emerald-500' };
    return { border: 'border-gray-500', text: 'text-gray-500' };
};

const OrderCard: React.FC<{ order: Order; onClick: () => void; customerName: string }> = ({ order, onClick, customerName }) => {
    const colorInfo = getStatusColorInfo(order.status);
    return (
        <div 
            onClick={onClick}
            className={`bg-surface p-4 rounded-lg shadow-md cursor-pointer hover:shadow-lg hover:bg-gray-700 transition-all duration-200 border-l-4 ${colorInfo.border}`}
        >
            <div className="flex justify-between items-center">
                <p className="text-sm font-bold text-primary">{order.order_number}</p>
                <p className="text-xs text-text-secondary">{new Date(order.order_date).toLocaleDateString()}</p>
            </div>
            <p className="text-md font-semibold text-text-primary mt-2">{customerName}</p>
            <p className="text-sm text-text-secondary">Total: {order.total_amount.toFixed(2)} €</p>
        </div>
    );
};

const KanbanColumn: React.FC<{ title: OrderStatus; orders: Order[]; onCardClick: (order: Order) => void; customers: Customer[] }> = ({ title, orders, onCardClick, customers }) => {
    const customerMap = useMemo(() => new Map(customers.map(c => [c.customer_id, c.company_name])), [customers]);
    
    return (
        <div className="bg-background rounded-lg p-3 w-80 flex-shrink-0">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-text-primary">{title}</h3>
                <span className="bg-primary text-white text-xs font-bold px-2 py-1 rounded-full">{orders.length}</span>
            </div>
            <div className="space-y-3 overflow-y-auto h-[calc(100vh-32rem)] pr-1">
                {orders.map(order => (
                    <OrderCard 
                        key={order.order_id} 
                        order={order} 
                        onClick={() => onCardClick(order)}
                        customerName={customerMap.get(order.customer_id) || 'Client Inconnu'}
                    />
                ))}
            </div>
        </div>
    );
}

const OrderKanbanView: React.FC = () => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

    const fetchAllData = async () => {
        setLoading(true);
        try {
             const [fetchedOrders, fetchedCustomers] = await Promise.all([
                api.getOrders(),
                api.getCustomers()
            ]);
            setOrders(fetchedOrders);
            setCustomers(fetchedCustomers);
        } catch (error) {
            console.error("Failed to fetch data", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAllData();
    }, []);

    const handleCloseModal = (updatedOrder?: Order) => {
        if(updatedOrder) {
            setOrders(prevOrders => prevOrders.map(o => o.order_id === updatedOrder.order_id ? updatedOrder : o));
        }
        setSelectedOrder(null);
    };
    
    const ordersByStatus = useMemo(() => {
        return orders.reduce((acc, order) => {
            (acc[order.status] = acc[order.status] || []).push(order);
            return acc;
        }, {} as Record<OrderStatus, Order[]>);
    }, [orders]);

    if (loading) return <div className="text-center p-10">Chargement des commandes...</div>;

    return (
        <div className="bg-surface p-4 rounded-lg border border-border">
            <div className="flex space-x-4 overflow-x-auto pb-4">
                {statusOrder.map(status => (
                    <KanbanColumn 
                        key={status}
                        title={status}
                        orders={ordersByStatus[status] || []}
                        onCardClick={setSelectedOrder}
                        customers={customers}
                    />
                ))}
                {selectedOrder && (
                    <OrderDetailModal 
                        orderId={selectedOrder.order_id}
                        onClose={handleCloseModal}
                    />
                )}
            </div>
        </div>
    );
};

export default OrderKanbanView;