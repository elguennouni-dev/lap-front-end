import React, { useState, useEffect, useCallback } from 'react';
import { Order, Customer, Product, User, UserRole, OrderStatus, TaskStatus, Task } from '../../types';
import { api } from '../../services/api';
import { useAppContext } from '../../contexts/AppContext';
import { generateOrderSummary } from '../../services/geminiService';

interface OrderDetailModalProps {
  orderId: number;
  onClose: (updatedOrder?: Order) => void;
}

const OrderDetailModal: React.FC<OrderDetailModalProps> = ({ orderId, onClose }) => {
  const { currentUser, users } = useAppContext();
  const [order, setOrder] = useState<Order | null>(null);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [summary, setSummary] = useState<string>('');
  const [summaryLoading, setSummaryLoading] = useState<boolean>(false);
  
  const [assignee, setAssignee] = useState<string>('');

  const designers = users.filter(u => u.roles.includes(UserRole.DESIGNER));
  const imprimeurs = users.filter(u => u.roles.includes(UserRole.IMPRIMEUR));

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [fetchedOrder, allCustomers, allProducts] = await Promise.all([
        api.getOrder(orderId),
        api.getCustomers(),
        api.getProducts()
      ]);

      if (fetchedOrder) {
        setOrder(fetchedOrder);
        const orderCustomer = allCustomers.find(c => c.customer_id === fetchedOrder.customer_id);
        setCustomer(orderCustomer || null);
      }
      setProducts(allProducts);
    } catch (error) {
      console.error("Failed to fetch order details", error);
    } finally {
      setLoading(false);
    }
  }, [orderId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAction = async (action: () => Promise<Order | Task | void>) => {
    setActionLoading(true);
    try {
      await action();
      const updatedOrder = await api.getOrder(orderId); // Refetch to get latest state
      setOrder(updatedOrder || null);
    } catch (error) {
        console.error("Action failed:", error);
    } finally {
        setActionLoading(false);
    }
  };
  
  const handleGenerateSummary = async () => {
    if (!order) return;
    setSummaryLoading(true);
    const result = await generateOrderSummary(order, customer || undefined, products, users);
    setSummary(result);
    setSummaryLoading(false);
  };

  const renderActions = () => {
    if (!order || !currentUser) return null;

    const isAdmin = currentUser.roles.includes(UserRole.ADMIN);

    const userTasks = order.tasks.filter(t => t.assigned_to === currentUser.user_id && t.status === TaskStatus.PENDING);

    return (
      <div className="bg-gray-800 p-4 rounded-b-lg space-y-4">
        {isAdmin && order.status === OrderStatus.NEW_ORDER && (
          <div className="flex items-center space-x-2">
            <select value={assignee} onChange={e => setAssignee(e.target.value)} className="bg-surface border border-border rounded-md p-2 w-full">
              <option value="">Sélectionner Designer</option>
              {designers.map(d => <option key={d.user_id} value={d.user_id}>{d.first_name} {d.last_name}</option>)}
            </select>
            <button disabled={!assignee || actionLoading} onClick={() => handleAction(() => api.assignTask(order.order_id, 'Design', parseInt(assignee), currentUser.user_id))} className="bg-primary hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md disabled:opacity-50">
              {actionLoading ? 'Assignation...' : 'Assigner Design'}
            </button>
          </div>
        )}
        {isAdmin && order.status === OrderStatus.DESIGN_PENDING_APPROVAL && (
           <div className="flex items-center space-x-2">
               <button onClick={() => handleAction(() => api.updateOrderStatus(order.order_id, OrderStatus.DESIGN_APPROVED))} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md w-full">Approuver Design</button>
               <button onClick={() => handleAction(() => api.updateOrderStatus(order.order_id, OrderStatus.DESIGN_ASSIGNED))} className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md w-full">Rejeter Design</button>
           </div>
        )}
        {isAdmin && order.status === OrderStatus.DESIGN_APPROVED && (
             <div className="flex items-center space-x-2">
                <select value={assignee} onChange={e => setAssignee(e.target.value)} className="bg-surface border border-border rounded-md p-2 w-full">
                    <option value="">Sélectionner Imprimeur</option>
                    {imprimeurs.map(d => <option key={d.user_id} value={d.user_id}>{d.first_name} {d.last_name}</option>)}
                </select>
                <button disabled={!assignee || actionLoading} onClick={() => handleAction(() => api.assignTask(order.order_id, 'Production', parseInt(assignee), currentUser.user_id))} className="bg-primary hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md disabled:opacity-50">
                    {actionLoading ? 'Assignation...' : 'Assigner Production'}
                </button>
            </div>
        )}
        {isAdmin && order.status === OrderStatus.PRODUCTION_COMPLETE && (
            <div className="flex items-center space-x-2">
                <button onClick={() => handleAction(() => api.updateOrderStatus(order.order_id, OrderStatus.FINAL_PENDING_APPROVAL))} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md w-full">Prêt pour Approbation Finale</button>
            </div>
        )}
         {isAdmin && order.status === OrderStatus.FINAL_PENDING_APPROVAL && (
            <div className="flex items-center space-x-2">
                <button onClick={() => handleAction(() => api.updateOrderStatus(order.order_id, OrderStatus.COMPLETED))} className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-md w-full">Approuver & Terminer</button>
                 <button onClick={() => handleAction(() => api.updateOrderStatus(order.order_id, OrderStatus.PRODUCTION_ASSIGNED))} className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md w-full">Rejeter</button>
            </div>
        )}
        {userTasks.map(task => (
            <div key={task.task_id} className="border-t border-border pt-4">
                <p className="font-semibold text-center text-yellow-400">Nouvelle tâche : {task.step_name}</p>
                 <div className="flex items-center space-x-2 mt-2">
                    <button onClick={() => handleAction(() => api.updateTaskStatus(order.order_id, task.task_id, TaskStatus.ACCEPTED))} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md w-full">Accepter Tâche</button>
                    <button onClick={() => handleAction(() => api.updateTaskStatus(order.order_id, task.task_id, TaskStatus.REJECTED))} className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md w-full">Rejeter Tâche</button>
                </div>
            </div>
        ))}
         {(order.status === OrderStatus.DESIGN_IN_PROGRESS && order.tasks.some(t => t.assigned_to === currentUser.user_id && t.step_name === 'Design' && t.status === TaskStatus.ACCEPTED)) ||
          (order.status === OrderStatus.PRODUCTION_IN_PROGRESS && order.tasks.some(t => t.assigned_to === currentUser.user_id && t.step_name === 'Production' && t.status === TaskStatus.ACCEPTED)) ? (
             <div className="border-t border-border pt-4">
                 <button onClick={() => handleAction(() => api.updateTaskStatus(order.order_id, order.tasks.find(t=>t.assigned_to === currentUser.user_id && t.status === TaskStatus.ACCEPTED)!.task_id, TaskStatus.COMPLETED))} className="bg-secondary hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-md w-full">
                    Marquer la Tâche comme Terminée
                 </button>
             </div>
        ) : null}

      </div>
    );
  };


  if (loading) return <div>Chargement...</div>;
  if (!order) return <div>Commande non trouvée</div>;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50" onClick={() => onClose(order)}>
      <div className="bg-surface rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="p-6 border-b border-border">
          <h2 className="text-2xl font-bold text-text-primary">{order.order_number}</h2>
          <p className="text-text-secondary">{customer?.company_name}</p>
          <span className="mt-2 inline-block bg-primary/20 text-primary text-sm font-medium mr-2 px-2.5 py-0.5 rounded-full">{order.status}</span>
        </div>
        <div className="p-6 overflow-y-auto flex-grow">
          <div className="grid grid-cols-2 gap-4 mb-6">
              <div><span className="font-semibold text-text-secondary">Date Commande:</span> {new Date(order.order_date).toLocaleDateString('fr-FR')}</div>
              <div><span className="font-semibold text-text-secondary">Date Livraison:</span> {new Date(order.delivery_date).toLocaleDateString('fr-FR')}</div>
              <div><span className="font-semibold text-text-secondary">Total:</span> {order.total_amount.toFixed(2)} €</div>
          </div>
          <h3 className="font-bold text-lg mb-2 text-text-primary">Articles de la Commande</h3>
          <ul className="divide-y divide-border">
            {order.items.map(item => {
              const product = products.find(p => p.product_id === item.product_id);
              return (
                <li key={item.order_item_id} className="py-2 flex justify-between">
                  <span>{item.quantity} x {product?.product_name || '...'}</span>
                  <span>{item.total_price.toFixed(2)} €</span>
                </li>
              );
            })}
          </ul>
          <h3 className="font-bold text-lg mt-6 mb-2 text-text-primary">Tâches</h3>
          {order.tasks.length > 0 ? (
            <ul className="divide-y divide-border">
                {order.tasks.map(task => {
                    const assignee = users.find(u => u.user_id === task.assigned_to);
                    return (
                        <li key={task.task_id} className="py-2">
                           <p><strong>{task.step_name}:</strong> {task.status} - <em>{assignee ? `${assignee.first_name} ${assignee.last_name}` : 'Non assigné'}</em></p>
                        </li>
                    )
                })}
            </ul>
          ) : <p className="text-text-secondary">Aucune tâche assignée pour le moment.</p>}

           <div className="mt-6">
            <h3 className="font-bold text-lg mb-2 text-text-primary">Résumé IA</h3>
            <button
              onClick={handleGenerateSummary}
              disabled={summaryLoading}
              className="mb-2 bg-secondary/80 hover:bg-secondary text-white font-bold py-2 px-4 rounded-md disabled:opacity-50"
            >
              {summaryLoading ? 'Génération...' : 'Générer un Résumé'}
            </button>
            {summary && <div className="p-4 bg-background rounded-md border border-border text-text-secondary whitespace-pre-wrap">{summary}</div>}
          </div>
        </div>
        {renderActions()}
      </div>
    </div>
  );
};

export default OrderDetailModal;