import { MOCK_USERS, MOCK_ORDERS, MOCK_CUSTOMERS, MOCK_PRODUCTS } from '../data/mockData';
import { User, Order, OrderStatus, Customer, Product, Task, TaskStatus } from '../types';

let users: User[] = MOCK_USERS;
let orders: Order[] = MOCK_ORDERS;

const simulateNetwork = (delay = 500) => new Promise(res => setTimeout(res, delay));

export const api = {
  getUsers: async (): Promise<User[]> => {
    await simulateNetwork();
    return [...users];
  },
  
  getUser: async (userId: number): Promise<User | undefined> => {
    await simulateNetwork();
    return users.find(u => u.user_id === userId);
  },

  getUserByEmail: async (email: string): Promise<User | undefined> => {
    await simulateNetwork();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase());
  },

  getCustomers: async (): Promise<Customer[]> => {
    await simulateNetwork();
    return [...MOCK_CUSTOMERS];
  },

  getProducts: async (): Promise<Product[]> => {
    await simulateNetwork();
    return [...MOCK_PRODUCTS];
  },

  getOrders: async (): Promise<Order[]> => {
    await simulateNetwork();
    return [...orders].sort((a, b) => new Date(b.order_date).getTime() - new Date(a.order_date).getTime());
  },
  
  getOrder: async (orderId: number): Promise<Order | undefined> => {
    await simulateNetwork();
    return orders.find(o => o.order_id === orderId);
  },
  
  updateOrderStatus: async (orderId: number, status: OrderStatus): Promise<Order> => {
    await simulateNetwork(800);
    orders = orders.map(o => o.order_id === orderId ? { ...o, status } : o);
    const updatedOrder = orders.find(o => o.order_id === orderId);
    if (!updatedOrder) throw new Error("Order not found");
    return updatedOrder;
  },

  assignTask: async (orderId: number, step_name: string, assigned_to: number, assigned_by: number): Promise<Order> => {
    await simulateNetwork();
    const order = orders.find(o => o.order_id === orderId);
    if (!order) throw new Error("Order not found");

    const newTask: Task = {
        task_id: Date.now(),
        order_id: orderId,
        step_name,
        assigned_to,
        assigned_by,
        status: TaskStatus.PENDING,
    };
    
    order.tasks.push(newTask);

    let nextStatus: OrderStatus;
    if (step_name === 'Design') {
        nextStatus = OrderStatus.DESIGN_ASSIGNED;
    } else if (step_name === 'Production') {
        nextStatus = OrderStatus.PRODUCTION_ASSIGNED;
    } else {
        nextStatus = order.status;
    }

    order.status = nextStatus;

    orders = orders.map(o => o.order_id === orderId ? order : o);
    return order;
  },

  updateTaskStatus: async (orderId: number, taskId: number, taskStatus: TaskStatus): Promise<Task> => {
    await simulateNetwork();
    const order = orders.find(o => o.order_id === orderId);
    if (!order) throw new Error("Order not found");

    const task = order.tasks.find(t => t.task_id === taskId);
    if(!task) throw new Error("Task not found");
    
    task.status = taskStatus;

    if (taskStatus === TaskStatus.ACCEPTED) {
        if (task.step_name === 'Design') order.status = OrderStatus.DESIGN_IN_PROGRESS;
        if (task.step_name === 'Production') order.status = OrderStatus.PRODUCTION_IN_PROGRESS;
    } else if (taskStatus === TaskStatus.COMPLETED) {
        if (task.step_name === 'Design') order.status = OrderStatus.DESIGN_PENDING_APPROVAL;
        if (task.step_name === 'Production') order.status = OrderStatus.PRODUCTION_COMPLETE;
    } else if (taskStatus === TaskStatus.REJECTED) {
        // Logic to move order status back might be needed here.
        // For now, just reject the task
    }
    
    orders = orders.map(o => o.order_id === orderId ? order : o);

    return task;
  },

  createOrder: async (orderData: Omit<Order, 'order_id' | 'order_number' | 'tasks'>): Promise<Order> => {
    await simulateNetwork();
    const newOrder: Order = {
        ...orderData,
        order_id: Date.now(),
        order_number: `CMD-${Date.now().toString().slice(-6)}`,
        tasks: [],
    };
    orders.unshift(newOrder);
    return newOrder;
  }
};