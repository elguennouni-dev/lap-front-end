import { GoogleGenAI } from "@google/genai";
import { Order, Customer, Product, User } from '../types';

export const generateOrderSummary = async (
    order: Order,
    customer: Customer | undefined,
    products: Product[],
    users: User[]
): Promise<string> => {
    const API_KEY = process.env.API_KEY;

    if (!API_KEY) {
        console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
        return "La clé API Gemini n'est pas configurée. La fonctionnalité de résumé est indisponible.";
    }

    const ai = new GoogleGenAI({ apiKey: API_KEY });

    const creator = users.find(u => u.user_id === order.created_by);

    const prompt = `
        Générez un résumé concis et professionnel pour la commande suivante.
        Le résumé doit être en texte brut, adapté à un aperçu rapide.
        Incluez les détails les plus importants.

        Détails de la commande :
        - Numéro de commande : ${order.order_number}
        - Client : ${customer?.company_name || 'N/A'}
        - Date de commande : ${new Date(order.order_date).toLocaleDateString('fr-FR')}
        - Date de livraison : ${new Date(order.delivery_date).toLocaleDateString('fr-FR')}
        - Montant total : ${order.total_amount.toFixed(2)} €
        - Statut actuel : ${order.status}
        - Créé par : ${creator?.first_name} ${creator?.last_name}
        - Articles :
          ${order.items.map(item => {
            const product = products.find(p => p.product_id === item.product_id);
            return `- ${item.quantity} x ${product?.product_name || 'Produit inconnu'}`;
          }).join('\n          ')}

        Générez le résumé maintenant.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating summary with Gemini:", error);
        return "Échec de la génération du résumé en raison d'une erreur API.";
    }
};