import { User, UserRole, Order, OrderStatus, Customer, Product, OrderItem, TaskStatus } from '../types';

export const MOCK_USERS: User[] = [
  { user_id: 1, username: 'admin', email: 'admin@example.com', first_name: 'Admin', last_name: 'User', roles: [UserRole.ADMIN], is_active: true },
  { user_id: 2, username: 'commercial', email: 'commercial@example.com', first_name: 'Sarah', last_name: 'Connor', roles: [UserRole.COMMERCIAL], is_active: true },
  { user_id: 3, username: 'designer1', email: 'designer1@example.com', first_name: 'John', last_name: 'Doe', roles: [UserRole.DESIGNER], is_active: true },
  { user_id: 4, username: 'designer2', email: 'designer2@example.com', first_name: 'Jane', last_name: 'Smith', roles: [UserRole.DESIGNER], is_active: true },
  { user_id: 5, username: 'imprimeur1', email: 'imprimeur1@example.com', first_name: 'Mike', last_name: 'Ross', roles: [UserRole.IMPRIMEUR], is_active: true },
  { user_id: 6, username: 'imprimeur2', email: 'imprimeur2@example.com', first_name: 'Harvey', last_name: 'Specter', roles: [UserRole.IMPRIMEUR], is_active: true },
];

export const MOCK_CUSTOMERS: Customer[] = [
    { customer_id: 1, company_name: 'Stark Industries', contact_name: 'Tony Stark', email: 'tony@stark.com' },
    { customer_id: 2, company_name: 'Wayne Enterprises', contact_name: 'Bruce Wayne', email: 'bruce@wayne.com' },
];

export const MOCK_PRODUCTS: Product[] = [
    { product_id: 1, product_name: 'Cartes de visite (x500)', unit_price: 50 },
    { product_id: 2, product_name: 'Flyers A4 (x1000)', unit_price: 120 },
    { product_id: 3, product_name: 'Bannière Roll-up', unit_price: 85 },
];

const generateItems = (productId: number, quantity: number): OrderItem => {
    const product = MOCK_PRODUCTS.find(p => p.product_id === productId);
    if (!product) throw new Error("Product not found");
    return {
        order_item_id: Date.now() + Math.random(),
        product_id: productId,
        quantity,
        unit_price: product.unit_price,
        total_price: product.unit_price * quantity,
    }
};

export const MOCK_ORDERS: Order[] = [
    {
        order_id: 1,
        order_number: 'CMD-001',
        customer_id: 1,
        status: OrderStatus.NEW_ORDER,
        order_date: '2023-10-26T10:00:00Z',
        delivery_date: '2023-11-10T10:00:00Z',
        total_amount: 170,
        created_by: 2,
        items: [generateItems(1, 1), generateItems(2, 1)],
        tasks: []
    },
    {
        order_id: 2,
        order_number: 'CMD-002',
        customer_id: 2,
        status: OrderStatus.DESIGN_ASSIGNED,
        order_date: '2023-10-25T11:00:00Z',
        delivery_date: '2023-11-08T10:00:00Z',
        total_amount: 85,
        created_by: 2,
        items: [generateItems(3, 1)],
        tasks: [{ task_id: 1, order_id: 2, step_name: 'Design', assigned_to: 3, assigned_by: 1, status: TaskStatus.PENDING }]
    },
    {
        order_id: 3,
        order_number: 'CMD-003',
        customer_id: 1,
        status: OrderStatus.DESIGN_PENDING_APPROVAL,
        order_date: '2023-10-24T12:00:00Z',
        delivery_date: '2023-11-05T10:00:00Z',
        total_amount: 100,
        created_by: 2,
        items: [generateItems(1, 2)],
        tasks: [{ task_id: 2, order_id: 3, step_name: 'Design', assigned_to: 4, assigned_by: 1, status: TaskStatus.COMPLETED }]
    },
    {
        order_id: 4,
        order_number: 'CMD-004',
        customer_id: 2,
        status: OrderStatus.DESIGN_APPROVED,
        order_date: '2023-10-23T14:00:00Z',
        delivery_date: '2023-11-04T10:00:00Z',
        total_amount: 240,
        created_by: 2,
        items: [generateItems(2, 2)],
        tasks: [{ task_id: 3, order_id: 4, step_name: 'Design', assigned_to: 3, assigned_by: 1, status: TaskStatus.COMPLETED }]
    },
    {
        order_id: 5,
        order_number: 'CMD-005',
        customer_id: 1,
        status: OrderStatus.PRODUCTION_COMPLETE,
        order_date: '2023-10-22T15:00:00Z',
        delivery_date: '2023-11-03T10:00:00Z',
        total_amount: 255,
        created_by: 2,
        items: [generateItems(3, 3)],
        tasks: [
            { task_id: 4, order_id: 5, step_name: 'Design', assigned_to: 4, assigned_by: 1, status: TaskStatus.COMPLETED },
            { task_id: 5, order_id: 5, step_name: 'Production', assigned_to: 5, assigned_by: 1, status: TaskStatus.COMPLETED }
        ]
    },
    {
        order_id: 6,
        order_number: 'CMD-006',
        customer_id: 2,
        status: OrderStatus.COMPLETED,
        order_date: '2023-10-20T16:00:00Z',
        delivery_date: '2023-10-30T10:00:00Z',
        total_amount: 50,
        created_by: 2,
        items: [generateItems(1, 1)],
        tasks: [
             { task_id: 6, order_id: 6, step_name: 'Design', assigned_to: 3, assigned_by: 1, status: TaskStatus.COMPLETED },
             { task_id: 7, order_id: 6, step_name: 'Production', assigned_to: 6, assigned_by: 1, status: TaskStatus.COMPLETED }
        ]
    }
];